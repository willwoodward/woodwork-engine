from components.knowledge_base import knowledge_base

class graph_database(knowledge_base):
    def __init__(self, name):
        super().__init__(name)
