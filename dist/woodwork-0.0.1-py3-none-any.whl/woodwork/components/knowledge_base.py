from woodwork.components.component import component

class knowledge_base(component):
    def __init__(self, name):
        super().__init__(name, "knowledge_base")
