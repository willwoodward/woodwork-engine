class component:
    def __init__(self, name, type):
        self.name = name
        self.type = type
        