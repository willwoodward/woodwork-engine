from woodwork.config_parser import main_function

def main():
    main_function()
    
if __name__ == "__main__":
    main()